# QueueFlow — Interactive Digital Queue Management

A working queue simulation built with Flask, SQLite, HTML, CSS, and JavaScript.

## Features
- Generate sequential tokens (A001, A002, ...)
- Current serving token and waiting/completed/total counts
- Administrator controls to call the next token and complete service
- Waiting, Serving, and Completed status indicators
- Token search and estimated waiting time
- Auto-refreshing dashboard (every 3 seconds)
- Reset into a new session while preserving older session records in SQLite
- Responsive layout for mobile and desktop

## Run on Windows
1. Install Python 3.10 or newer.
2. Open PowerShell in this project folder.
3. (Recommended) Create a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install requirements:
   ```powershell
   py -m pip install -r requirements.txt
   ```
5. Start the application:
   ```powershell
   py app.py
   ```
6. Open `http://127.0.0.1:5000` in your browser.

The SQLite database (`queue.db`) is created automatically beside `app.py`.
This is a demonstration app. Add administrator authentication before using it in a real organization.
