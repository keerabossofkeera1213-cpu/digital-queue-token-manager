from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path
from datetime import datetime

app = Flask(__name__)
DB_PATH = Path(__file__).with_name("queue.db")

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                token_number INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'Waiting',
                created_at TEXT NOT NULL,
                called_at TEXT,
                completed_at TEXT,
                session_id INTEGER NOT NULL DEFAULT 1
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS app_state (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                session_id INTEGER NOT NULL DEFAULT 1
            )
        """)
        conn.execute("INSERT OR IGNORE INTO app_state (id, session_id) VALUES (1, 1)")

def current_session(conn):
    row = conn.execute("SELECT session_id FROM app_state WHERE id=1").fetchone()
    return row["session_id"] if row else 1

def get_dashboard_data():
    with connect_db() as conn:
        session_id = current_session(conn)
        rows = conn.execute(
            "SELECT * FROM tokens WHERE session_id=? ORDER BY token_number ASC",
            (session_id,)
        ).fetchall()
        tokens = [dict(row) for row in rows]
        serving = next((t for t in tokens if t["status"] == "Serving"), None)
        waiting = sum(1 for t in tokens if t["status"] == "Waiting")
        completed = sum(1 for t in tokens if t["status"] == "Completed")
        total = len(tokens)
        # Estimate is a simple configurable simulation: 5 minutes per person ahead.
        for token in tokens:
            ahead = sum(
                1 for other in tokens
                if other["status"] == "Waiting" and other["token_number"] < token["token_number"]
            )
            token["estimated_minutes"] = ahead * 5 if token["status"] == "Waiting" else 0
        return {
            "tokens": tokens,
            "serving": serving,
            "waiting_count": waiting,
            "completed_count": completed,
            "total_count": total,
            "session_id": session_id,
            "next_token_number": max([t["token_number"] for t in tokens], default=0) + 1
        }

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/queue")
def queue_data():
    return jsonify(get_dashboard_data())

@app.post("/api/tokens")
def create_token():
    with connect_db() as conn:
        session_id = current_session(conn)
        row = conn.execute(
            "SELECT COALESCE(MAX(token_number), 0) + 1 AS next_no FROM tokens WHERE session_id=?",
            (session_id,)
        ).fetchone()
        token_number = row["next_no"]
        now = datetime.now().isoformat(timespec="seconds")
        conn.execute(
            "INSERT INTO tokens (token_number, status, created_at, session_id) VALUES (?, 'Waiting', ?, ?)",
            (token_number, now, session_id)
        )
    return jsonify({"message": "Token created", "token_number": token_number}), 201

@app.post("/api/next")
def call_next():
    with connect_db() as conn:
        session_id = current_session(conn)
        # Finish any token currently being served before calling the next one.
        current = conn.execute(
            "SELECT id FROM tokens WHERE session_id=? AND status='Serving' LIMIT 1",
            (session_id,)
        ).fetchone()
        if current:
            return jsonify({"error": "Complete the currently serving token before calling the next one."}), 409
        nxt = conn.execute(
            "SELECT id, token_number FROM tokens WHERE session_id=? AND status='Waiting' ORDER BY token_number ASC LIMIT 1",
            (session_id,)
        ).fetchone()
        if not nxt:
            return jsonify({"error": "There are no waiting tokens."}), 404
        conn.execute(
            "UPDATE tokens SET status='Serving', called_at=? WHERE id=?",
            (datetime.now().isoformat(timespec="seconds"), nxt["id"])
        )
    return jsonify({"message": "Next token called", "token_number": nxt["token_number"]})

@app.post("/api/complete")
def complete_token():
    data = request.get_json(silent=True) or {}
    token_id = data.get("id")
    if not token_id:
        return jsonify({"error": "Token ID is required."}), 400
    with connect_db() as conn:
        session_id = current_session(conn)
        cur = conn.execute(
            "UPDATE tokens SET status='Completed', completed_at=? WHERE id=? AND session_id=? AND status='Serving'",
            (datetime.now().isoformat(timespec="seconds"), token_id, session_id)
        )
        if cur.rowcount == 0:
            return jsonify({"error": "Only the currently serving token can be completed."}), 409
    return jsonify({"message": "Token marked completed"})

@app.post("/api/reset")
def reset_queue():
    with connect_db() as conn:
        session_id = current_session(conn) + 1
        conn.execute("UPDATE app_state SET session_id=? WHERE id=1", (session_id,))
    return jsonify({"message": "Queue reset for a new session", "session_id": session_id})

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
