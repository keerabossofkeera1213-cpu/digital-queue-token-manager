const $ = (id) => document.getElementById(id);
let latestData = null;
let toastTimer;

function showToast(message, isError = false) {
  const toast = $("toast");
  toast.textContent = message;
  toast.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.className = "toast", 2800);
}
function tokenLabel(n) { return "A" + String(n).padStart(3, "0"); }
function formatTime(value) {
  if (!value) return "—";
  const d = new Date(value);
  return d.toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"});
}
function statusClass(status) {
  return status === "Serving" ? "serving" : status === "Completed" ? "completed" : "waiting";
}
function render(data) {
  latestData = data;
  $("servingToken").textContent = data.serving ? tokenLabel(data.serving.token_number) : "—";
  $("servingHint").textContent = data.serving ? "Currently at the service counter" : "No token is being served";
  $("waitingCount").textContent = data.waiting_count;
  $("completedCount").textContent = data.completed_count;
  $("totalCount").textContent = data.total_count;
  $("sessionLabel").textContent = "Session " + data.session_id;
  $("queueCount").textContent = data.total_count + (data.total_count === 1 ? " token" : " tokens");
  $("adminCurrentToken").textContent = data.serving ? tokenLabel(data.serving.token_number) : "—";
  $("adminCurrentStatus").textContent = data.serving ? "Service is in progress" : "Waiting for the next visitor";
  $("completeBtn").disabled = !data.serving;
  $("nextBtn").disabled = !!data.serving || data.waiting_count === 0;
  const search = $("searchInput").value.trim().toLowerCase().replace(/^a/, "");
  const visible = data.tokens.filter(t => !search || String(t.token_number).includes(search));
  $("showingText").textContent = `Showing ${visible.length} of ${data.total_count} tokens`;
  const body = $("queueBody");
  if (!visible.length) {
    body.innerHTML = `<tr><td colspan="4" class="empty-state">${data.total_count ? "No tokens match your search." : "No tokens yet. Generate the first token to get started."}</td></tr>`;
    return;
  }
  body.innerHTML = visible.map(t => {
    const wait = t.status === "Waiting" ? `${t.estimated_minutes} min` : "—";
    return `<tr>
      <td class="token-cell">${tokenLabel(t.token_number)}</td>
      <td>${formatTime(t.created_at)}</td>
      <td>${wait}</td>
      <td><span class="status status-${statusClass(t.status)}">${t.status}</span></td>
    </tr>`;
  }).join("");
}
async function refreshQueue() {
  try {
    const response = await fetch("/api/queue");
    render(await response.json());
  } catch (e) {
    showToast("Unable to connect to the server.", true);
  }
}
async function postAction(url, body = null) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: body ? JSON.stringify(body) : null
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    await refreshQueue();
    return data;
  } catch (e) {
    showToast(e.message || "Request failed.", true);
    return null;
  }
}
$("generateBtn").addEventListener("click", async () => {
  const data = await postAction("/api/tokens");
  if (data) showToast(`Token ${tokenLabel(data.token_number)} generated successfully.`);
});
$("nextBtn").addEventListener("click", async () => {
  const data = await postAction("/api/next");
  if (data) showToast(`Now calling ${tokenLabel(data.token_number)}.`);
});
$("completeBtn").addEventListener("click", async () => {
  if (!latestData || !latestData.serving) return;
  const data = await postAction("/api/complete", {id: latestData.serving.id});
  if (data) showToast("Current token marked as completed.");
});
$("resetBtn").addEventListener("click", async () => {
  if (!confirm("Start a new queue session? Current tokens will no longer appear in the active queue, but their records will remain in the database.")) return;
  const data = await postAction("/api/reset");
  if (data) showToast("Queue reset. New session started.");
});
$("searchInput").addEventListener("input", () => { if (latestData) render(latestData); });
refreshQueue();
setInterval(refreshQueue, 3000);
